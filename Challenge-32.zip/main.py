def greet():
  print('Hello World!')

# call the function
greet()

print('Outside function')